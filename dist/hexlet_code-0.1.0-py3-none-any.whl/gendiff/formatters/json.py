#!/usr/bin/env python3

import json as js


def json(data):
    result = js.dumps(data, indent=4)
    return result


def main():
    pass


if __name__ == '__main__':
    main()
